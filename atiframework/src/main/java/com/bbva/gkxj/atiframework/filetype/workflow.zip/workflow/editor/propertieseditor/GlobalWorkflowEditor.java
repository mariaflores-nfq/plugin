package com.bbva.gkxj.atiframework.filetype.workflow.editor.propertieseditor;

import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkFlowStyles;
import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData;
import com.intellij.util.ui.JBUI;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Editor de propiedades globales para el archivo de Workflow.
 * <p>
 * A diferencia de los editores de nodos individuales, esta clase se encarga de la configuración
 * de nivel raíz del documento. Gestiona metadatos generales y coordina dos secciones dinámicas
 * críticas: {@link TaskExecutorsSectionPanel} y {@link EnvironmentVariablesSectionPanel}.
 * </p>
 * <p>
 * Los campos de identificación técnica (Workflow Code, ID, Status) se presentan como solo lectura
 * para garantizar la integridad de la cabecera del JSON, permitiendo la edición de la descripción
 * y listas de instancias intermedias.
 * </p>
 */
public class GlobalWorkflowEditor extends AbstractComponentEditor {

    /** Campo para el código identificador del flujo de trabajo (Solo lectura). */
    private JTextField workflowCodeField;

    /** Campo que indica el estado actual del flujo (Solo lectura). */
    private JTextField statusField;

    /** Campo para la lista de IDs de instancias intermedias, manejado como una cadena separada por comas. */
    private JTextField middleInstanceField;

    /** Sección para la gestión de hilos y ejecutores de tareas asíncronas. */
    private TaskExecutorsSectionPanel executorsSection;

    /** Sección para la gestión de las variables de entorno del flujo. */
    private EnvironmentVariablesSectionPanel variablesSection;

    /**
     * Construye la interfaz de usuario global.
     * <p>
     * Organiza el panel en tres bloques principales:
     * <ol>
     * <li><b>General:</b> Metadatos básicos del flujo.</li>
     * <li><b>Middle Instances:</b> Configuración de instancias.</li>
     * <li><b>Secciones Dinámicas:</b> Listas de ejecutores y variables de entorno.</li>
     * </ol>
     * </p>
     */
    @Override
    protected void buildSpecificUI() {

        // --- Encabezado de Sección General ---
        JPanel generalHeader = new JPanel(new BorderLayout());
        generalHeader.setBackground(WorkFlowStyles.UI_PANEL_BG);
        generalHeader.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("General");
        title.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        generalHeader.add(title, BorderLayout.WEST);
        generalHeader.setBorder(JBUI.Borders.emptyBottom(10));
        contentPanel.add(generalHeader);

        // --- Inicialización de campos de metadatos ---
        workflowCodeField = new JTextField();
        setReadOnlyStyle(workflowCodeField);

        idField = new JTextField();
        setReadOnlyStyle(idField);

        statusField = new JTextField();
        setReadOnlyStyle(statusField);

        descriptionField = new JTextArea();
        descriptionField.setRows(3);
        descriptionField.setLineWrap(true);
        descriptionField.setWrapStyleWord(true);
        descriptionField.setBorder(BorderFactory.createLineBorder(WorkFlowStyles.UI_BORDER));
        addChangeListener(descriptionField);

        addFormField("Workflow code", workflowCodeField);
        addFormField("ID", idField);
        addFormField("Status", statusField);
        addFormField("Description", descriptionField);

        // --- Sección Middle Instance Id List ---
        contentPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        JLabel middleTitle = new JLabel("Middle Instance Id List");
        middleTitle.setForeground(WorkFlowStyles.UI_TEXT_SUB);
        middleTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.add(middleTitle);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        middleInstanceField = new JTextField();
        addChangeListener(middleInstanceField);
        addFormField("Middle Instance Id", middleInstanceField);

        // --- Integración de Secciones Dinámicas ---
        contentPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Se pasa notifyChange como callback para que cualquier cambio interno
        // en las listas marque el documento como modificado.
        executorsSection = new TaskExecutorsSectionPanel(this::notifyChange);
        contentPanel.add(executorsSection);

        variablesSection = new EnvironmentVariablesSectionPanel(this::notifyChange);
        contentPanel.add(variablesSection);
    }

    /**
     * Carga los datos globales del modelo JSON en los componentes de la interfaz.
     * <p>
     * Procesa la lista de {@code middleInstanceIdList} convirtiéndola en una cadena legible
     * separada por comas y delega la carga de las colecciones a las secciones correspondientes.
     * </p>
     * @param data El objeto {@link WorkflowJsonData} que representa el archivo completo.
     */
    @Override
    public void loadData(WorkflowJsonData data) {
        isUpdating = true;
        try {
            workflowCodeField.setText(data.getWorkflowCode() != null ? data.getWorkflowCode() : "");
            idField.setText(data.getId() != null ? data.getId() : "");
            statusField.setText(data.getStatus() != null ? data.getStatus() : "");
            descriptionField.setText(data.getDescription() != null ? data.getDescription() : "");

            // Conversión de Lista a String (UI)
            if (data.getMiddleInstanceIdList() != null && !data.getMiddleInstanceIdList().isEmpty()) {
                middleInstanceField.setText(String.join(", ", data.getMiddleInstanceIdList()));
            } else {
                middleInstanceField.setText("");
            }

            executorsSection.loadData(data.getTaskExecutors());
            variablesSection.loadData(data.getEnvironmentVariables());
        } finally {
            isUpdating = false;
        }
    }

    /**
     * Persiste los datos de la interfaz global de vuelta al modelo de datos.
     * <p>
     * Realiza el proceso inverso para las instancias intermedias, transformando la cadena
     * de texto en una lista de strings mediante expresiones regulares para limpiar espacios.
     * </p>
     * @param data Objeto {@link WorkflowJsonData} de destino.
     */
    @Override
    public void saveData(WorkflowJsonData data) {
        data.setDescription(descriptionField.getText());

        // Persistir cambios en las sub-secciones
        executorsSection.saveData(data);
        variablesSection.saveData(data);

        // Conversión de String (UI) a Lista (Modelo)
        String middleText = middleInstanceField.getText().trim();
        if (!middleText.isEmpty()) {
            data.setMiddleInstanceIdList(new ArrayList<>(Arrays.asList(middleText.split("\\s*,\\s*"))));
        } else {
            data.setMiddleInstanceIdList(null);
        }
    }

    /**
     * Aplica el estilo visual de solo lectura a campos específicos de la cabecera.
     * @param field El campo de texto a bloquear.
     */
    private void setReadOnlyStyle(JTextField field) {
        field.setEditable(false);
        field.setBackground(WorkFlowStyles.UI_READONLY_BG);
        field.setForeground(WorkFlowStyles.UI_READONLY_TEXT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(WorkFlowStyles.UI_READONLY_BORDER),
                JBUI.Borders.empty(4, 8)
        ));
    }

    /**
     * Método auxiliar para añadir filas de acción con botones.
     * Útil para futuras expansiones de la interfaz global.
     * @param text Texto descriptivo de la fila.
     */
    private void addListActionRow(String text) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(WorkFlowStyles.UI_PANEL_BG);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JButton btnAdd = new JButton("+");
        btnAdd.setFont(new Font("Arial", Font.BOLD, 22));
        btnAdd.setForeground(WorkFlowStyles.UI_ICON_ACTION);
        btnAdd.setOpaque(false);
        btnAdd.setContentAreaFilled(false);
        btnAdd.setFocusPainted(false);
        btnAdd.setBorder(null);
        btnAdd.setCursor(new Cursor(Cursor.HAND_CURSOR));

        row.add(label, BorderLayout.WEST);
        row.add(btnAdd, BorderLayout.EAST);
        row.setBorder(JBUI.Borders.empty(5, 0));

        contentPanel.add(row);
    }
}