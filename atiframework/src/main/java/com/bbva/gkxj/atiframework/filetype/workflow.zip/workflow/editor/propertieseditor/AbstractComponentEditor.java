package com.bbva.gkxj.atiframework.filetype.workflow.editor.propertieseditor;

import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkFlowStyles;
import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;
import java.awt.*;

/**
 * Clase base abstracta para la creación de editores de propiedades de componentes.
 * <p>
 * Proporciona la infraestructura común para construir formularios Swing, gestionar el estilo
 * visual acorde al diseño de la plataforma y notificar cambios mediante un callback.
 * </p>
 * Implementa {@link ComponentEditorStrategy} para integrarse en la factoría de editores.
 */
public abstract class AbstractComponentEditor implements ComponentEditorStrategy {

    /** Panel principal que contiene todos los elementos de UI del editor. */
    protected JPanel contentPanel;

    /** Callback que se ejecuta cuando se detecta un cambio en cualquier campo del formulario. */
    protected Runnable onChangeCallback;

    /** * Flag para evitar disparar eventos de cambio durante la carga de datos (programática).
     */
    protected boolean isUpdating = false;

    /** Campo estándar para el identificador único del componente. */
    protected JTextField idField;

    /** Campo estándar para el código técnico del componente. */
    protected JTextField componentCodeField;

    /** Área de texto para la descripción detallada del componente. */
    protected JTextArea descriptionField;

    /**
     * Construye la interfaz base del editor.
     * Inicializa los campos comunes y delega la construcción de campos específicos a las subclases.
     * * @param onChangeCallback Acción a realizar cuando el usuario modifica un dato.
     * @return El panel {@link JPanel} configurado con la UI del editor.
     */
    @Override
    public JPanel buildUI(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;

        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(WorkFlowStyles.UI_PANEL_BG);

        idField = new JTextField();
        componentCodeField = new JTextField();

        descriptionField = new JTextArea();
        descriptionField.setLineWrap(true);
        descriptionField.setWrapStyleWord(true);

        // Registro de listeners para detección de cambios en tiempo real
        addChangeListener(idField);
        addChangeListener(componentCodeField);
        addChangeListener(descriptionField);

        // Hook para que la subclase añada sus propios campos
        buildSpecificUI();

        return contentPanel;
    }

    /**
     * Método que deben implementar las subclases para añadir campos específicos
     * (ej. combos, tablas, checkboxes) al {@link #contentPanel}.
     */
    protected abstract void buildSpecificUI();

    /**
     * Sobrecarga de carga de datos para manejar objetos genéricos,
     * delegando en la implementación específica de {@link WorkflowJsonData}.
     */
    @Override
    public void loadData(Object value) {
        if (value instanceof WorkflowJsonData) {
            loadData((WorkflowJsonData) value);
        }
    }

    /**
     * Sobrecarga de guardado de datos para manejar objetos genéricos.
     */
    @Override
    public void saveData(Object value) {
        if (value instanceof WorkflowJsonData) {
            saveData((WorkflowJsonData) value);
        }
    }

    /**
     * Añade una sección con título visualmente diferenciada en el panel de contenido.
     * * @param title Texto del título de la sección.
     */
    protected void addSectionTitle(String title) {
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(WorkFlowStyles.UI_PANEL_BG);
        titlePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        titlePanel.setBorder(JBUI.Borders.empty(10, 0, 15, 0));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        titleLabel.setForeground(WorkFlowStyles.UI_TEXT_MAIN);

        titlePanel.add(titleLabel, BorderLayout.WEST);
        contentPanel.add(titlePanel);
    }

    /**
     * Carga los valores desde el modelo de datos hacia los componentes de la UI.
     * @param data El modelo {@link WorkflowJsonData} de origen.
     */
    public abstract void loadData(WorkflowJsonData data);

    /**
     * Salva los valores desde los componentes de la UI hacia el modelo de datos.
     * @param data El modelo {@link WorkflowJsonData} de destino.
     */
    public abstract void saveData(WorkflowJsonData data);


    /**
     * Utilidad para añadir de forma estandarizada una etiqueta y un campo de entrada al formulario.
     * Aplica márgenes, fuentes y bordes definidos en {@link WorkFlowStyles}.
     * * @param labelText      Texto de la etiqueta descriptiva.
     * @param inputComponent Componente de entrada (JTextField, JComboBox, etc.).
     * @return El panel contenedor del campo.
     */
    protected JPanel addFormField(String labelText, JComponent inputComponent) {
        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setBackground(WorkFlowStyles.UI_PANEL_BG);
        wrapper.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(WorkFlowStyles.UI_PANEL_BG);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(WorkFlowStyles.UI_TEXT_MAIN);
        label.setBorder(JBUI.Borders.emptyBottom(5));

        int height = 30;
        if (inputComponent instanceof JTextArea) {
            height = 60;
        }

        inputComponent.setPreferredSize(new Dimension(0, height));
        inputComponent.setMaximumSize(new Dimension(Integer.MAX_VALUE, height));

        if (!(inputComponent instanceof JComboBox)) {
            inputComponent.setBackground(inputComponent.isOpaque() ? inputComponent.getBackground() : WorkFlowStyles.UI_PANEL_BG);
            inputComponent.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(WorkFlowStyles.UI_BORDER, 1),
                    JBUI.Borders.empty(4, 8)
            ));
        }

        row.add(label, BorderLayout.NORTH);
        row.add(inputComponent, BorderLayout.CENTER);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, height + 25));

        wrapper.add(row);
        wrapper.add(Box.createRigidArea(new Dimension(0, 15)));

        contentPanel.add(wrapper);
        return wrapper;
    }


    /**
     * Aplica un estilo visual de "solo lectura" a un componente, deshabilitando su edición
     * y cambiando sus colores a los definidos para campos bloqueados.
     * * @param field Componente a estilizar.
     */
    protected void setReadOnlyStyle(JComponent field) {
        if (field instanceof JTextComponent) {
            ((JTextComponent) field).setEditable(false);
        }
        field.setBackground(WorkFlowStyles.UI_READONLY_BG);
        field.setForeground(WorkFlowStyles.UI_READONLY_TEXT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(WorkFlowStyles.UI_READONLY_BORDER),
                JBUI.Borders.empty(4, 8)
        ));
    }

    /**
     * Registra un listener de documentos en un componente de texto para notificar cambios.
     * @param field Componente de texto.
     */
    protected void addChangeListener(JTextComponent field) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { notifyChange(); }
            public void removeUpdate(DocumentEvent e) { notifyChange(); }
            public void changedUpdate(DocumentEvent e) { notifyChange(); }
        });
    }

    /**
     * Registra un listener de acción en un JComboBox para notificar cambios.
     * @param combo El combo box a observar.
     */
    protected void addComboListener(JComboBox<?> combo) {
        combo.addActionListener(e -> notifyChange());
    }

    /**
     * Ejecuta el callback de notificación de cambios si no se está en un proceso de
     * actualización interna (isUpdating = false).
     */
    protected void notifyChange() {
        if (!isUpdating && onChangeCallback != null) {
            onChangeCallback.run();
        }
    }
}