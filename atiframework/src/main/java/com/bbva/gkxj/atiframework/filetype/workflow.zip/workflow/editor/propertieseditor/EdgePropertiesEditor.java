package com.bbva.gkxj.atiframework.filetype.workflow.editor.propertieseditor;

import com.bbva.gkxj.atiframework.components.AtiScriptPanel;
import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData.EdgeData;
import com.intellij.ui.JBColor;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 * Editor de propiedades para las conexiones (Edges) entre nodos del workflow.
 * <p>
 * Este editor implementa {@link ComponentEditorStrategy} para gestionar la configuración de las aristas.
 * Actualmente, su funcionalidad principal se activa cuando el nodo origen es un <b>Router</b>,
 * permitiendo definir la lógica de encaminamiento mediante scripts.
 * </p>
 */
public class EdgePropertiesEditor implements ComponentEditorStrategy {

    /** Panel contenedor principal del editor. */
    private JPanel contentPanel;

    /** Callback para notificar cambios en la UI hacia el modelo del grafo. */
    private Runnable onChangeCallback;

    /** Referencia a los datos de la arista actual que se está editando. */
    private EdgeData currentData;

    /** Campo para mostrar el tipo de canal (Directo, Cola, etc.). Generalmente de solo lectura. */
    private JTextField channelTypeField;

    /** Área de texto para definir el script de routing cuando la conexión nace de un Router. */
    private AtiScriptPanel scriptRoutingField;

    /**
     * Inicializa el contenedor básico del editor.
     * @param onChangeCallback Acción a ejecutar cuando se detecten cambios.
     * @return El panel configurado con layout vertical.
     */
    @Override
    public JPanel buildUI(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        contentPanel.setBackground(JBColor.PanelBackground);
        return contentPanel;
    }

    /**
     * Carga y renderiza dinámicamente la UI basada en los datos de la arista.
     * <p>
     * Si el nodo de origen es un Router, se construye la interfaz para editar el script de ruteo.
     * En otros casos, el panel permanece limpio o con información básica.
     * </p>
     * @param value Objeto de datos, se espera una instancia de {@link EdgeData}.
     */
    @Override
    public void loadData(Object value) {
        contentPanel.removeAll();

        if (!(value instanceof EdgeData)) return;
        this.currentData = (EdgeData) value;

        // Lógica condicional: El routing script solo aplica si viene de un Router
        if ("Router".equalsIgnoreCase(currentData.getSourceType())) {
            buildRouterUI();
        }

        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /**
     * Construye los componentes visuales específicos para conexiones de salida de un Router.
     * Incluye el tipo de canal y el editor de scripts.
     */
    private void buildRouterUI() {
        // Configuración del Título de Sección
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel titleLabel = new JLabel("Flow Details");
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        titlePanel.add(titleLabel, BorderLayout.WEST);
        titlePanel.setBorder(JBUI.Borders.empty(10, 0, 15, 0));
        contentPanel.add(titlePanel);

        // Campo: Tipo de Canal (Solo lectura)
        String cType = currentData.getChannelType() != null ? currentData.getChannelType() : "DIRECT";
        channelTypeField = new JTextField(cType);
        channelTypeField.setEditable(false);
        // Colores adaptativos para modo claro/oscuro de IntelliJ
        channelTypeField.setBackground(new JBColor(new Color(245, 245, 245), new Color(60, 63, 65)));
        channelTypeField.setForeground(JBColor.GRAY);
        contentPanel.add(createFormField("Channel Type", channelTypeField));

        // Campo: Script de Routing
        scriptRoutingField = new AtiScriptPanel();
        if (currentData.getScriptRouting() != null) {
            scriptRoutingField.setText(currentData.getScriptRouting());
        }

        // AtiScriptPanel expone getDocument() que devuelve el documento subyacente del RSyntaxTextArea
        scriptRoutingField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { notifyChange(); }
            @Override public void removeUpdate(DocumentEvent e) { notifyChange(); }
            @Override public void changedUpdate(DocumentEvent e) { notifyChange(); }
        });

        JPanel scriptPanel = createFormField("Script Routing", scriptRoutingField);
        // Le damos un poco más de altura mínima porque es un editor más completo
        scriptPanel.setMinimumSize(new Dimension(0, 150));
        contentPanel.add(scriptPanel);
    }

    /**
     * Persiste los cambios realizados en la UI hacia el objeto de datos de la arista.
     * @param value Objeto de datos donde se guardará la información.
     */
    @Override
    public void saveData(Object value) {
        if (value instanceof EdgeData && currentData != null && "Router".equalsIgnoreCase(currentData.getSourceType())) {
            EdgeData data = (EdgeData) value;
            if (scriptRoutingField != null) {
                // AtiScriptPanel expone getText() directamente
                data.setScriptRouting(scriptRoutingField.getText().trim());
            }
        }
    }

    /**
     * Ejecuta el callback de notificación de cambios para disparar la sincronización con el modelo.
     */
    private void notifyChange() {
        if (onChangeCallback != null) onChangeCallback.run();
    }

    /**
     * Utilidad para crear una fila de formulario con etiqueta y componente.
     * @param labelText Texto de la etiqueta.
     * @param field     Componente de entrada (JTextField, AtiScriptPanel, etc.).
     * @return Panel contenedor con el estilo aplicado.
     */
    private JPanel createFormField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setBorder(JBUI.Borders.emptyBottom(10));

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(JBColor.DARK_GRAY);
        label.setBorder(JBUI.Borders.emptyBottom(4));
        panel.add(label, BorderLayout.NORTH);

        if (field instanceof JTextArea) {
            ((JTextArea) field).setRows(4);
            ((JTextArea) field).setLineWrap(true);
            ((JTextArea) field).setWrapStyleWord(true);
        }

        // Evitamos sobreescribir el borde si es un AtiScriptPanel,
        // ya que este componente gestiona sus propios bordes de Focus/Blur.
        if (!(field instanceof AtiScriptPanel)) {
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(JBColor.border(), 1),
                    JBUI.Borders.empty(4, 8)
            ));
        }

        panel.add(field, BorderLayout.CENTER);

        // Fijar alturas para evitar comportamientos erráticos en el scroll
        int preferredHeight = panel.getPreferredSize().height;
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, preferredHeight));
        panel.setMinimumSize(new Dimension(0, preferredHeight));

        return panel;
    }
}