package com.bbva.gkxj.atiframework.filetype.workflow.editor.propertieseditor;

import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData.TaskExecutorData;
import com.intellij.icons.AllIcons;
import com.intellij.ui.JBColor;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Panel de UI para la edición individual de un Task Executor.
 * <p>
 * Este componente permite configurar los parámetros de un pool de hilos de Spring,
 * incluyendo el código identificador, prefijos de nombres de hilos y capacidades
 * del pool (Core, Max y Queue).
 * </p>
 * <p>
 * Proporciona retroalimentación visual inmediata actualizando el título del panel
 * a medida que el usuario modifica el campo "Code".
 * </p>
 */
public class TaskExecutorItemPanel extends JPanel {

    /** Campos para la configuración técnica del pool de hilos. */
    private final JTextField codeField, prefixField, corePoolField, maxPoolField, queueField;

    /** Área de texto para la descripción del propósito del ejecutor. */
    private final JTextArea descField;

    /** Etiqueta de encabezado que muestra el índice y el código del ejecutor. */
    private final JLabel headerLabel;

    /** Índice actual del ejecutor dentro de la lista global de la sección. */
    private int currentIndex;

    /**
     * Construye un nuevo panel de edición para un Task Executor.
     * * @param data      Objeto DTO con los datos iniciales del ejecutor.
     * @param index     Índice visual (posicionamiento) en la lista.
     * @param onDelete  Callback para manejar la eliminación de este panel.
     * @param onChange  Callback para notificar cambios en los campos y disparar el autoguardado.
     */
    public TaskExecutorItemPanel(TaskExecutorData data, int index,
                                 Consumer<TaskExecutorItemPanel> onDelete,
                                 Runnable onChange) {
        this.currentIndex = index;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setAlignmentX(Component.LEFT_ALIGNMENT);
        setBackground(JBColor.PanelBackground);

        // Estilo visual: borde con separador inferior y margen interno
        setBorder(BorderFactory.createCompoundBorder(
                JBUI.Borders.emptyBottom(15),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(JBColor.border()),
                        JBUI.Borders.empty(10)
                )
        ));

        // --- Configuración del Encabezado ---
        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        headerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        String initialTitle = data.code == null || data.code.isEmpty() ? "New Executor" : data.code;
        headerLabel = new JLabel(String.format("%02d %s", index, initialTitle));
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerLabel.setForeground(new JBColor(new Color(26, 115, 232), new Color(88, 157, 246)));

        // Botón de borrado con icono nativo de IntelliJ
        JButton btnDelete = new JButton(AllIcons.General.Delete);
        btnDelete.setOpaque(false);
        btnDelete.setContentAreaFilled(false);
        btnDelete.setBorderPainted(false);
        btnDelete.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDelete.addActionListener(e -> onDelete.accept(this));

        headerRow.add(headerLabel, BorderLayout.WEST);
        headerRow.add(btnDelete, BorderLayout.EAST);

        add(headerRow);
        add(Box.createRigidArea(new Dimension(0, 10)));

        // --- Inicialización de campos con valores por defecto ---
        codeField = new JTextField(data.code != null ? data.code : "");
        prefixField = new JTextField(data.namePrefix != null ? data.namePrefix : "");
        descField = new JTextArea(data.description != null ? data.description : "");
        corePoolField = new JTextField(data.corePoolSize != null ? data.corePoolSize : "3");
        maxPoolField = new JTextField(data.maxPoolSize != null ? data.maxPoolSize : "10");
        queueField = new JTextField(data.queueCapacity != null ? data.queueCapacity : "50");

        // Listener genérico para detección de cambios
        DocumentListener globalDocListener = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { onChange.run(); }
            @Override public void removeUpdate(DocumentEvent e) { onChange.run(); }
            @Override public void changedUpdate(DocumentEvent e) { onChange.run(); }
        };

        // Listener específico para el código: actualiza el label del encabezado sincrónicamente
        codeField.getDocument().addDocumentListener(new DocumentListener() {
            private void updateTitle() {
                String currentText = codeField.getText().trim();
                headerLabel.setText(String.format("%02d %s", currentIndex, currentText.isEmpty() ? "New Executor" : currentText));
                onChange.run();
            }
            @Override public void insertUpdate(DocumentEvent e) { updateTitle(); }
            @Override public void removeUpdate(DocumentEvent e) { updateTitle(); }
            @Override public void changedUpdate(DocumentEvent e) { updateTitle(); }
        });

        // Registro de escuchadores en todos los componentes
        prefixField.getDocument().addDocumentListener(globalDocListener);
        descField.getDocument().addDocumentListener(globalDocListener);
        corePoolField.getDocument().addDocumentListener(globalDocListener);
        maxPoolField.getDocument().addDocumentListener(globalDocListener);
        queueField.getDocument().addDocumentListener(globalDocListener);

        // --- Construcción del Formulario ---
        add(createFormField("Task Executor Code", codeField));
        add(createFormField("Name Prefix", prefixField));
        add(createFormField("Description", descField));
        add(createFormField("Core Pool Size", corePoolField));
        add(createFormField("Max Pool Size", maxPoolField));
        add(createFormField("Queue Capacity", queueField));
    }

    /**
     * Mapea los valores de la UI a un nuevo objeto de datos.
     * * @return Objeto {@link TaskExecutorData} con la información actual del panel.
     */
    public TaskExecutorData getData() {
        TaskExecutorData data = new TaskExecutorData();
        data.code = codeField.getText().trim();
        data.namePrefix = prefixField.getText().trim();
        data.description = descField.getText().trim();
        data.corePoolSize = corePoolField.getText().trim();
        data.maxPoolSize = maxPoolField.getText().trim();
        data.queueCapacity = queueField.getText().trim();
        return data;
    }

    /**
     * Actualiza el índice numérico mostrado en el encabezado.
     * Utilizado para re-indexar la lista tras la eliminación de elementos.
     * * @param newIndex Nuevo índice a mostrar.
     */
    public void updateIndex(int newIndex) {
        this.currentIndex = newIndex;
        String currentText = codeField.getText().trim();
        headerLabel.setText(String.format("%02d %s", currentIndex, currentText.isEmpty() ? "New Executor" : currentText));
    }

    /**
     * Utilidad para crear filas de formulario con etiqueta y validación de estilo.
     * * @param labelText Texto de la etiqueta.
     * @param field     Componente de entrada.
     * @return Panel contenedor configurado.
     */
    private JPanel createFormField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setBorder(JBUI.Borders.emptyBottom(10));

        if (labelText != null) {
            JLabel label = new JLabel(labelText);
            label.setFont(new Font("Segoe UI", Font.BOLD, 12));
            label.setForeground(JBColor.DARK_GRAY);
            label.setBorder(JBUI.Borders.emptyBottom(4));
            panel.add(label, BorderLayout.NORTH);
        } else {
            panel.setBorder(JBUI.Borders.emptyBottom(5));
        }

        if (field instanceof JTextArea) {
            ((JTextArea) field).setRows(2);
            ((JTextArea) field).setLineWrap(true);
            ((JTextArea) field).setWrapStyleWord(true);
        }

        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(JBColor.border(), 1),
                JBUI.Borders.empty(4, 8)
        ));

        panel.add(field, BorderLayout.CENTER);

        // Gestión estricta de tamaños para evitar deformaciones en BoxLayout
        int preferredHeight = panel.getPreferredSize().height;
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, preferredHeight));
        panel.setMinimumSize(new Dimension(0, preferredHeight));

        return panel;
    }
}