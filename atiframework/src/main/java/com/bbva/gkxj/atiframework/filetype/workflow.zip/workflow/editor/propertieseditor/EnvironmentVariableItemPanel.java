package com.bbva.gkxj.atiframework.filetype.workflow.editor.propertieseditor;

import com.bbva.gkxj.atiframework.components.AtiScriptPanel;
import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData.EnvironmentVariableData;
import com.intellij.icons.AllIcons;
import com.intellij.ui.JBColor;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Panel de UI que representa el editor de una variable de entorno individual.
 * <p>
 * Este componente es utilizado principalmente dentro de {@link GlobalWorkflowEditor} para permitir
 * la edición detallada de cada variable, incluyendo su nombre, tipo, expresiones regulares,
 * longitud y lógica mediante scripts.
 * </p>
 * <p>
 * Implementa una sincronización reactiva: al cambiar el nombre en el campo de texto,
 * el encabezado del panel se actualiza automáticamente para reflejar el estado actual.
 * </p>
 */
public class EnvironmentVariableItemPanel extends JPanel {

    /** Campos de entrada para las propiedades de texto corto. */
    private final JTextField nameField, fieldLengthField;

    /** Selector para el tipo de dato de la variable. */
    private final JComboBox<String> typeCombo;

    /** Áreas de texto simples para descripciones y expresiones regulares. */
    private final JTextArea regexField, descField, fixedValueField;

    /** Panel de scripting avanzado para la lógica de la variable. */
    private final AtiScriptPanel scriptField;

    /** Etiqueta de encabezado que muestra el índice y el nombre de la variable. */
    private final JLabel headerLabel;

    /** Índice actual de la variable en la lista global de variables de entorno. */
    private int currentIndex;

    /**
     * Construye un nuevo panel de edición para una variable de entorno.
     * @param data      Objeto con los datos iniciales de la variable.
     * @param index     Posición numérica de la variable en la lista.
     * @param onDelete  Callback ejecutado cuando el usuario pulsa el botón de eliminar.
     * @param onChange  Callback ejecutado ante cualquier cambio en los campos para persistencia.
     */
    public EnvironmentVariableItemPanel(EnvironmentVariableData data, int index,
                                        Consumer<EnvironmentVariableItemPanel> onDelete,
                                        Runnable onChange) {
        this.currentIndex = index;

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setAlignmentX(Component.LEFT_ALIGNMENT);
        setBackground(JBColor.PanelBackground);

        // Estilo visual: borde con margen inferior para separar de otros items
        setBorder(BorderFactory.createCompoundBorder(
                JBUI.Borders.emptyBottom(15),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(JBColor.border()),
                        JBUI.Borders.empty(10)
                )
        ));

        // --- Fila de Encabezado (Título e Icono de Borrado) ---
        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        headerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        String initialTitle = data.variableName == null || data.variableName.isEmpty() ? "nueva_variable" : data.variableName;
        headerLabel = new JLabel(String.format("%02d %s", index, initialTitle));
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerLabel.setForeground(new JBColor(new Color(26, 115, 232), new Color(88, 157, 246)));

        JButton btnDelete = new JButton(AllIcons.General.Delete);
        btnDelete.setToolTipText("Remove this variable");
        btnDelete.setOpaque(false);
        btnDelete.setContentAreaFilled(false);
        btnDelete.setBorderPainted(false);
        btnDelete.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDelete.addActionListener(e -> onDelete.accept(this));

        headerRow.add(headerLabel, BorderLayout.WEST);
        headerRow.add(btnDelete, BorderLayout.EAST);
        add(headerRow);
        add(Box.createRigidArea(new Dimension(0, 10)));

        // --- Inicialización de Campos ---
        nameField = new JTextField(data.variableName != null ? data.variableName : "");
        typeCombo = new JComboBox<>(new String[]{"String", "Integer", "Boolean", "Object"});
        typeCombo.setSelectedItem(data.type != null ? data.type : "String");

        regexField = new JTextArea(data.regularExpression != null ? data.regularExpression : "");
        fieldLengthField = new JTextField(data.fieldLength != null ? data.fieldLength : "");
        descField = new JTextArea(data.description != null ? data.description : "");
        fixedValueField = new JTextArea(data.fixedValue != null ? data.fixedValue : "");

        // Inicialización del nuevo panel de script
        scriptField = new AtiScriptPanel();
        if (data.scriptValue != null) {
            scriptField.setText(data.scriptValue);
        }

        // --- Configuración de Listeners ---
        DocumentListener globalDocListener = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { onChange.run(); }
            @Override public void removeUpdate(DocumentEvent e) { onChange.run(); }
            @Override public void changedUpdate(DocumentEvent e) { onChange.run(); }
        };

        // Listener especial para el nombre: actualiza el título del encabezado en tiempo real
        nameField.getDocument().addDocumentListener(new DocumentListener() {
            private void updateTitle() {
                String currentText = nameField.getText().trim();
                headerLabel.setText(String.format("%02d %s", currentIndex, currentText.isEmpty() ? "nueva_variable" : currentText));
                onChange.run();
            }
            @Override public void insertUpdate(DocumentEvent e) { updateTitle(); }
            @Override public void removeUpdate(DocumentEvent e) { updateTitle(); }
            @Override public void changedUpdate(DocumentEvent e) { updateTitle(); }
        });

        typeCombo.addActionListener(e -> onChange.run());
        regexField.getDocument().addDocumentListener(globalDocListener);
        fieldLengthField.getDocument().addDocumentListener(globalDocListener);
        descField.getDocument().addDocumentListener(globalDocListener);
        fixedValueField.getDocument().addDocumentListener(globalDocListener);
        scriptField.getDocument().addDocumentListener(globalDocListener);

        // --- Montaje de la UI ---
        add(createFormField("Variable Name", nameField));
        add(createFormField("Type of variable", typeCombo));
        add(createFormField("Field Configuration", regexField));
        add(createFormField(null, fieldLengthField)); // Campo sin etiqueta (agrupado)
        add(createFormField("Description", descField));
        add(createFormField("Fixed Value", fixedValueField));

        JPanel scriptContainer = createFormField("Script Value", scriptField);
        add(scriptContainer);
    }

    /**
     * Recolecta los datos actuales de los campos de la interfaz y los encapsula en un objeto DTO.
     * @return Una nueva instancia de {@link EnvironmentVariableData} con la información del panel.
     */
    public EnvironmentVariableData getData() {
        EnvironmentVariableData data = new EnvironmentVariableData();
        data.variableName = nameField.getText().trim();
        data.type = (String) typeCombo.getSelectedItem();
        data.regularExpression = regexField.getText().trim();
        data.fieldLength = fieldLengthField.getText().trim();
        data.description = descField.getText().trim();
        data.fixedValue = fixedValueField.getText().trim();
        data.scriptValue = scriptField.getText().trim(); // Extracción directa usando el método del panel
        return data;
    }

    /**
     * Actualiza el índice visual del panel.
     * Útil cuando se eliminan elementos anteriores de la lista y se requiere reordenar la numeración.
     * @param newIndex El nuevo índice base 0 o base 1 a mostrar.
     */
    public void updateIndex(int newIndex) {
        this.currentIndex = newIndex;
        String currentText = nameField.getText().trim();
        headerLabel.setText(String.format("%02d %s", currentIndex, currentText.isEmpty() ? "nueva_variable" : currentText));
    }

    /**
     * Método de utilidad para crear una fila de formulario estandarizada.
     * @param labelText Texto de la etiqueta superior. Si es null, no se crea etiqueta.
     * @param field     El componente de entrada de datos.
     * @return Un JPanel con la disposición de formulario configurada.
     */
    private JPanel createFormField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setBorder(JBUI.Borders.emptyBottom(10));

        int maxHeight = 50;

        if (labelText != null) {
            JLabel label = new JLabel(labelText);
            label.setFont(new Font("Segoe UI", Font.BOLD, 12));
            label.setForeground(JBColor.DARK_GRAY);
            label.setBorder(JBUI.Borders.emptyBottom(4));
            panel.add(label, BorderLayout.NORTH);
        } else {
            panel.setBorder(JBUI.Borders.emptyBottom(5));
        }

        // Configuración específica según el tipo de componente
        if (field instanceof JTextArea) {
            ((JTextArea) field).setRows(2);
            ((JTextArea) field).setLineWrap(true);
            ((JTextArea) field).setWrapStyleWord(true);
            maxHeight = 80;
        } else if (field instanceof JComboBox) {
            maxHeight = 55;
        } else if (field instanceof AtiScriptPanel) {
            maxHeight = 250; // Le damos una altura generosa al editor de código
        }

        // Evitamos sobrescribir los bordes dinámicos del AtiScriptPanel
        if (!(field instanceof AtiScriptPanel)) {
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(JBColor.border(), 1),
                    JBUI.Borders.empty(4, 8)
            ));
        }

        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, maxHeight));
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }
}