package com.bbva.gkxj.atiframework.filetype.workflow.controller;

import com.bbva.gkxj.atiframework.filetype.batch.editor.utils.EditorKeyboardHandler;
import com.bbva.gkxj.atiframework.filetype.workflow.editor.PropertiesPanel;
import com.bbva.gkxj.atiframework.filetype.workflow.model.WorkflowJsonData;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.mxgraph.swing.handler.mxRubberband;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.mxGraphOutline;
import com.mxgraph.util.mxEvent;
import com.mxgraph.util.mxEventSource.mxIEventListener;
import com.mxgraph.util.mxUndoManager;
import com.mxgraph.view.mxGraph;

import javax.swing.*;
import java.awt.event.MouseWheelListener;

/**
 * Controlador principal y fachada (Facade) del editor de grafos.
 * <p>
 * Esta clase actúa como el orquestador central que inicializa y coordina los diferentes
 * sub-controladores especializados (Manejo de Datos, Interacción, Selección y Drag & Drop).
 * Expone métodos de alto nivel para interactuar con el grafo sin exponer la complejidad interna.
 */
public class GraphController {

    /** Componente visual principal que renderiza el grafo. */
    private final mxGraphComponent graphComponent;

    /** Modelo principal del grafo. */
    private final mxGraph graph;

    /** Componente visual que representa el minimapa (vista general). */
    protected mxGraphOutline graphOutline;

    /** Gestor del historial para deshacer/rehacer acciones. */
    private final mxUndoManager undoManager;

    /** Contexto del proyecto de IntelliJ actualmente activo. */
    private final Project project;

    /** Archivo virtual que representa el workflow abierto. */
    private final VirtualFile virtualFile;

    /** Indicador de si el grafo ha sufrido modificaciones no guardadas. */
    private boolean setModified;

    /** Tipo de conexión activa por defecto al crear nuevas flechas. */
    private String currentEdgeType = "DIRECT";

    // --- Sub-Controladores especializados ---

    /** Gestor encargado de la persistencia, exportación/importación y creación de nodos. */
    private final WorkflowDataManager dataManager;

    /** Gestor encargado de las herramientas del ratón (paneo, selección, conexión) y el zoom. */
    private final GraphInteractionHandler interactionHandler;

    /** Gestor encargado de escuchar los eventos de selección y actualizar el panel de propiedades. */
    private final GraphSelectionHandler selectionHandler;

    /** Gestor encargado de manejar los eventos de Drag and Drop desde la paleta. */
    private final WorkflowTransferHandler transferHandler;

    /** Controlador de la interfaz flotante (Context Pad) para conexiones y creación rápida. */
    private final WorkflowContextPadController contextPadController;

    /**
     * Interfaz para escuchar los cambios producidos en el modelo del grafo.
     */
    public interface GraphChangeListener {
        /**
         * Método invocado cuando se detecta un cambio en el grafo (movimiento, adición, eliminación, etc.).
         */
        void onGraphChanged();
    }

    /** Listener registrado para recibir notificaciones de cambios en el grafo. */
    private GraphChangeListener graphChangeListener;

    /**
     * Establece el listener que escuchará los cambios del grafo.
     *
     * @param listener El listener a registrar.
     */
    public void setGraphChangeListener(GraphChangeListener listener) {
        this.graphChangeListener = listener;
    }

    /**
     * Constructor del controlador principal.
     * Inicializa las configuraciones básicas del grafo y todos los sub-controladores necesarios.
     *
     * @param graphComponent El componente visual del grafo.
     * @param undoManager    El gestor de deshacer/rehacer.
     * @param project        El proyecto de IntelliJ (necesario para instanciar modales).
     * @param virtualFile    El archivo virtual del workflow actual.
     */
    public GraphController(mxGraphComponent graphComponent, mxUndoManager undoManager, Project project, VirtualFile virtualFile) {
        this.graphComponent = graphComponent;
        this.graph = graphComponent.getGraph();
        this.undoManager = undoManager;
        this.project = project;
        this.virtualFile = virtualFile;
        this.graphOutline = new mxGraphOutline(graphComponent);

        // Configuraciones base del lienzo y el grafo
        graphComponent.setAntiAlias(true);
        this.graph.setCellsEditable(false);
        this.graph.setHtmlLabels(true);
        this.graph.setLabelsVisible(true);
        this.graph.setAllowDanglingEdges(false);
        // Evita que las cajas se salgan por arriba o por la izquierda (coordenadas < 0)
        this.graph.setAllowNegativeCoordinates(false);
        this.graph.setBorder(80);

        // 1. Inicializar Gestor de Datos
        this.dataManager = new WorkflowDataManager(graphComponent);

        // 2. Inicializar herramientas de UI
        mxRubberband rubberband = new mxRubberband(graphComponent);
        new EditorKeyboardHandler(graphComponent);

        // 3. Inicializar Context Pad y conexiones (Inyectando dependencias requeridas para el Modal)
        this.contextPadController = new WorkflowContextPadController(graphComponent, dataManager, project, virtualFile);

        this.graphComponent.getConnectionHandler().setEnabled(true);
        this.graphComponent.setDragEnabled(false);
        this.graphComponent.setPageVisible(false);
        // Hace que el lienzo crezca automáticamente si arrastras una caja hacia la derecha o hacia abajo
        this.graphComponent.setAutoExtend(true);
        // Mueve las barras de scroll automáticamente mientras arrastras la caja cerca del borde
        this.graphComponent.setAutoScroll(true);

        // 4. Inicializar Handlers interactivos
        this.interactionHandler = new GraphInteractionHandler(graphComponent, contextPadController, rubberband);
        this.selectionHandler = new GraphSelectionHandler(graph, dataManager);
        this.transferHandler = new WorkflowTransferHandler(graphComponent, dataManager);

        setupBaseListeners();
        changeToolMode("NODE"); // Modo de selección por defecto
    }

    /**
     * Configura los listeners base del controlador, como el rastreador de modificaciones
     * y los eventos de la rueda del ratón para realizar zoom interactivo.
     */
    private void setupBaseListeners() {
        mxIEventListener changeTracker = (source, evt) -> {
            setModified = true;
            if (graphChangeListener != null) graphChangeListener.onGraphChanged();
        };
        graph.getModel().addListener(mxEvent.CHANGE, changeTracker);

        MouseWheelListener wheelTracker = e -> {
            if (e.getSource() instanceof com.mxgraph.swing.mxGraphOutline || e.isControlDown()) {
                if (e.getWheelRotation() < 0) graphComponent.zoomIn();
                else graphComponent.zoomOut();
            }
        };
        graphOutline.addMouseWheelListener(wheelTracker);
        graphComponent.addMouseWheelListener(wheelTracker);
    }

    /**
     * Configura los listeners encargados de mantener sincronizado el minimapa
     * con los cambios y repintados del grafo principal.
     *
     * @param layeredContainer El contenedor de capas donde se encuentra el minimapa.
     * @param outlineWidth     El ancho del minimapa.
     * @param outlineHeight    El alto del minimapa.
     */
    public void setupMinimapListeners(JLayeredPane layeredContainer, int outlineWidth, int outlineHeight) {
        mxIEventListener refreshAction = (sender, evt) -> SwingUtilities.invokeLater(() -> {
            if (graphOutline != null) {
                layeredContainer.revalidate();
                graph.repaint();
                layeredContainer.repaint();
            }
        });
        graph.getModel().addListener(mxEvent.CHANGE, refreshAction);
        graph.getView().addListener(mxEvent.UNDO, refreshAction);
        graph.getView().addListener(mxEvent.REPAINT, refreshAction);
    }

    /**
     * Vincula el panel de propiedades lateral al gestor de selecciones del grafo
     * y le inyecta las dependencias necesarias para leer los datos globales.
     *
     * @param panel El panel de propiedades a actualizar al seleccionar nodos.
     */
    public void setPropertiesPanel(PropertiesPanel panel) {
        // --- AQUÍ ESTÁ LA SOLUCIÓN DEL COMBO ---
        // Le inyectamos el grafo y el DataManager al PropertiesPanel
        panel.setGraph(this.graph);
        panel.setDataManager(this.dataManager);

        selectionHandler.setPropertiesPanel(panel);
    }

    /**
     * Cambia la herramienta activa del editor (ej: "HAND" para paneo, "NODE" para selección normal).
     * Delega la lógica al {@link GraphInteractionHandler}.
     *
     * @param toolId Identificador de la herramienta a activar.
     */
    public void changeToolMode(String toolId) {
        interactionHandler.changeToolMode(toolId);
    }

    /**
     * Carga el modelo de datos en formato JSON y renderiza el grafo correspondiente en el lienzo.
     * Delega la lógica de construcción al {@link WorkflowDataManager}.
     *
     * @param jsonData Los datos del workflow a cargar.
     */
    public void loadGraphFromData(WorkflowJsonData jsonData) {
        dataManager.loadGraphFromData(jsonData, () -> selectionHandler.showGlobalProperties());
    }

    /**
     * Procesa el grafo actual y lo exporta a un modelo de datos JSON.
     * Delega la lógica de extracción al {@link WorkflowDataManager}.
     *
     * @return El objeto {@link WorkflowJsonData} con la información de todos los nodos y flechas.
     */
    public WorkflowJsonData exportGraphToJsonData() {
        return dataManager.exportGraphToJsonData();
    }

    /**
     * Define el tipo de canal/estilo que se utilizará de forma activa al crear nuevas conexiones.
     *
     * @param type El tipo de conexión (ej: "DIRECT", "QUEUE").
     */
    public void setActiveEdgeStyle(String type) {
        this.currentEdgeType = type;
    }
}